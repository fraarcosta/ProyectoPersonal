// chat-store.ts
// Módulo compartido de conversaciones del Asistente de Soporte.
// Fuente de verdad: localStorage. Sincronización entre vistas: custom event.
// Todos los valores de estado son inmutables (siempre se reemplaza el array).
// 🔄 NEXT.JS: este módulo usa localStorage → sólo puede ejecutarse en el cliente.
"use client";

import { getAuthUser } from "../../_components/auth-store";

// ─── Constants ────────────────────────────────────────────────────────────────

export const CHAT_UPDATE_EVENT = "akena-chat-updated";

// getMockUser replaced by getAuthUser — Bug C fix: always return the logged-in user.
export function getMockUser(): ChatUser {
  const u = getAuthUser();
  return { id: u.id, name: u.name };
}

// ─── Types ────────────────────────────────────────────────────────────────────

export interface ChatUser {
  id: string;
  name: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: number;
}

export interface Conversation {
  id: string;
  /** Título automático: primer mensaje del usuario, truncado */
  title: string;
  oppId: string;
  userId: string;
  messages: ChatMessage[];
  createdAt: number;
  updatedAt: number;
}

// ─── Storage helpers ──────────────────────────────────────────────────────────

function storageKey(userId: string, oppId: string): string {
  return `akena-chats-${userId}-${oppId}`;
}

export function getConversations(oppId: string): Conversation[] {
  try {
    const userId = getAuthUser().id;
    const raw = localStorage.getItem(storageKey(userId, oppId));
    if (raw) {
      const parsed = JSON.parse(raw) as Conversation[];
      return parsed.sort((a, b) => b.updatedAt - a.updatedAt);
    }
  } catch {}
  return [];
}

function saveConversations(oppId: string, conversations: Conversation[]): void {
  try {
    const userId = getAuthUser().id;
    localStorage.setItem(storageKey(userId, oppId), JSON.stringify(conversations));
  } catch {}
}

// ─── Dispatch update signal ───────────────────────────────────────────────────

export function dispatchChatUpdate(oppId: string): void {
  window.dispatchEvent(
    new CustomEvent(CHAT_UPDATE_EVENT, { detail: { oppId } })
  );
}

// ─── CRUD operations ──────────────────────────────────────────────────────────

const WELCOME_MESSAGE: ChatMessage = {
  id: "welcome",
  role: "assistant",
  content:
    "Hola, soy el asistente de Akena. Puedo ayudarte con análisis del pliego, estrategia de oferta, definición de equipo y consultas sobre esta licitación. ¿En qué puedo ayudarte?",
  timestamp: Date.now(),
};

export function createConversation(oppId: string): Conversation {
  const userId = getAuthUser().id;
  const conv: Conversation = {
    id: `conv-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    title: "Nueva conversación",
    oppId,
    userId,
    messages: [{ ...WELCOME_MESSAGE, id: `welcome-${Date.now()}`, timestamp: Date.now() }],
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
  const existing = getConversations(oppId);
  saveConversations(oppId, [conv, ...existing]);
  dispatchChatUpdate(oppId);
  return conv;
}

export function updateConversation(oppId: string, conv: Conversation): void {
  const existing = getConversations(oppId);
  const idx = existing.findIndex((c) => c.id === conv.id);
  const updated = { ...conv, updatedAt: Date.now() };
  if (idx >= 0) {
    existing[idx] = updated;
  } else {
    existing.unshift(updated);
  }
  saveConversations(oppId, existing);
  dispatchChatUpdate(oppId);
}

export function getConversationById(oppId: string, convId: string): Conversation | null {
  return getConversations(oppId).find((c) => c.id === convId) ?? null;
}

// ─── Bot response generator ───────────────────────────────────────────────────

export function generateBotResponse(userMsg: string, oppName: string): string {
  const lower = userMsg.toLowerCase();

  if (
    lower.includes("pliego") ||
    lower.includes("pcap") ||
    lower.includes("ppt") ||
    lower.includes("clausula") ||
    lower.includes("requisito")
  ) {
    return `Analizando el pliego de «${oppName}»: los criterios de adjudicación se distribuyen en criterios automáticos (60 puntos) y criterios sujetos a juicio de valor (40 puntos). Los requisitos mínimos exigen clasificación empresarial Grupo V, Subgrupo 3, Categoría D y certificación ISO 27001 vigente. ¿Deseas que profundice en algún criterio concreto?`;
  }
  if (
    lower.includes("estrategia") ||
    lower.includes("win theme") ||
    lower.includes("diferencial") ||
    lower.includes("competencia")
  ) {
    return `Para «${oppName}» recomiendo centrar la estrategia en tres Win Themes: (1) experiencia acreditada en proyectos similares del sector público con resultados medibles, (2) metodología ágil con entregas incrementales y cuadro de mando en tiempo real, y (3) soporte post-implantación con SLA garantizado en contrato. ¿Quieres que desarrolle alguno de ellos?`;
  }
  if (
    lower.includes("equipo") ||
    lower.includes("perfil") ||
    lower.includes("recurso") ||
    lower.includes("organigrama")
  ) {
    return `El equipo mínimo para «${oppName}» incluye: Director de Proyecto (senior, ≥8 años), Arquitecto de Solución (≥5 años), 2 consultores funcionales senior y 3 desarrolladores con certificación vigente. El coste del equipo representa aprox. el 65% del PBL. ¿Necesitas detalle de perfiles o costeo?`;
  }
  if (
    lower.includes("precio") ||
    lower.includes("descuento") ||
    lower.includes("económic") ||
    lower.includes("oferta económica") ||
    lower.includes("margen")
  ) {
    return `Para maximizar la puntuación económica en «${oppName}», el modelo de baja proporcional recomienda un descuento entre el 8% y el 14% sobre el PBL. Bajas superiores al 16% mejoran el scoring marginal pero comprometen el margen operativo. ¿Quieres simular escenarios concretos?`;
  }
  if (
    lower.includes("resumen") ||
    lower.includes("criterio") ||
    lower.includes("adjudicación") ||
    lower.includes("puntuación")
  ) {
    return `El resumen de criterios de adjudicación para «${oppName}»: Oferta económica (30 pts), Plan de trabajo y metodología (20 pts), Recursos técnicos (10 pts), Memoria técnica (25 pts), Plan de riesgos (8 pts) y Mejoras (7 pts). Total: 100 puntos. ¿Quieres que analice algún criterio en profundidad?`;
  }

  return `He recibido tu consulta sobre «${oppName}». En la versión completa de Akena accederé a toda la documentación de la oportunidad para darte respuestas precisas y contextualizadas. Puedo orientarte sobre pliego, estrategia de oferta, equipo o cálculo económico. ¿Qué aspecto te interesa?`;
}